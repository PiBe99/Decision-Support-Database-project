# -*- coding: utf-8 -*-
"""
Created on Mon Nov 13 18:36:33 2023

@author: Niccolò
"""
import csv
from json import load
from popolamentoDB import inserimento
from popolamentoDBOPT import inserimentoOPT
import pyodbc
import csv

#funzione che apre file json e pone tutto in un unico dizionario
def open_json(file1,file2,file3):
    
    #apro file json
    jsAge = open(file1)
    jsStatus = open(file2)
    jsType = open(file3)
    
    #cario contenuto
    Dic_Age = load(jsAge)
    Dic_Status = load(jsStatus)
    Dic_Type = load(jsType)
    
    jsAge.close()
    jsStatus.close()
    jsType.close()
    
    #inserisce tutto in un unico dizionario Dict
    Dict = {} 
    Dict.update(Dic_Age)
    Dict.update(Dic_Status)
    Dict.update(Dic_Type)
    return Dict


#funzione che calcola prodotto del crime rate: itera per gli indici dei tre campi in questione 
#accedendo ai rispettivi valori con metodo get
def crime_rate(dizionario,indiciCol,row):
    totale = 1
    for i in indiciCol:
        valore = dizionario.get(row[i])
        totale = totale * valore
    return totale


#funzione per ottenere dizionari: utilizzata per file gun.csv, participant.csv e geo.csv
#i dizionari saranno utili per recuperare le chiavi in maniera più efficiente
def get_dict(file):
    fp = open(file, encoding = "utf-8")
    reader = csv.reader(fp)
    diz = {}
    header = 0
    #precisazione: di geo.csv usiamo le ultime due colonne che indicano la lat e la lng, il resto non
    #è presente nel file Police.csv e dunque errato metterlo come chiave del dizizionario
    if file != "geo.csv":
        for row in reader:
            if header == 0:
                header += 1
                continue
            diz[tuple([row[i] for i in range (1,len(row))])] = row[0]
    else:
        for row in reader:
            if header == 0:
                header += 1
                continue
            diz[tuple([row[i] for i in range (len(row) - 2,len(row))])] = row[0]
        
    fp.close()
    return diz

#crea il file custody.csv quando chiamata
def custody_table(dizCrimeGravity,dizParticipant,dizGun,dizGeo):
    filePolice = open("Police.csv")
    fileCustody = open("custody.csv","w",newline = "")
    
    reader = csv.reader(filePolice)
    writer = csv.writer(fileCustody)
    
    header = 0
    for row in reader:
        if header == 0:
            
            #ottengo tutti gli indici delle colonne di interesse per scrivere/chiamare fx definite
            #in precedenza
            idxCustody = row.index("custody_id")
            idxIncident = row.index("incident_id")
            idxDate = row.index("date_fk")
            
            idxType = row.index("participant_type")
            idxStatus = row.index("participant_status")
            idxGender = row.index("participant_gender")
            idx_age_group = row.index("participant_age_group")
            
            idxLat = row.index("latitude")
            idxLng = row.index("longitude")
            
            idxGStolen = row.index("gun_stolen")
            idxGType = row.index("gun_type")
            
            writer.writerow(["custody_id","incident_id","date_id","participant_id","geo_id","gun_id","crime_gravity"])
            header +=1
            continue
        
        tempList = []
        
        tempList.append(row[idxCustody])
        tempList.append(row[idxIncident])
        tempList.append(row[idxDate])
        
        #nelle successive 3 righe sfrutto i dizionari creati in precedenza per recuperare i valori delle
        #chiavi assocciate con il metodo get
        tempList.append(dizParticipant.get((row[idxType],row[idxStatus],row[idxGender],row[idx_age_group])))
        tempList.append(dizGeo.get((row[idxLat],row[idxLng])))
        tempList.append(dizGun.get((row[idxGStolen],row[idxGType])))
        
        #calcolo crime_gravity usando la fx crime_rate
        crime_gravity = crime_rate(dizCrimeGravity,[idxType,idxStatus,idx_age_group],row)
       
        tempList.append(crime_gravity)
        writer.writerow(tempList)
        
    filePolice.close()
    fileCustody.close()

if __name__ == '__main__':
    inp = input("Inserire \"yes\" per generare custody.csv, qualsiasi altro carattere altrimenti: ")
    if inp == "yes":
        jsAge = "dict_partecipant_age.json"
        jsStatus = "dict_partecipant_status.json"
        jsType = "dict_partecipant_type.json"
        dizCrimeGravity = open_json(jsAge, jsStatus, jsType) #chiamo fx per creare dizionario unico
        #ottengo dizionari per ognuno dei 3 file sotto
        dizGun = get_dict("gun.csv")
        dizParticipant = get_dict("participant.csv")
        dizGeo = get_dict("geo.csv")    
        custody_table(dizCrimeGravity, dizParticipant, dizGun, dizGeo)
        print("File custody.csv generato!")
    else:
        print("File custody.csv non generato!")

    inp = input("Inserire \"yes\" per inserire nella tablla Group_ID_9.Custody, qualsiasi altro carattere altrimenti: ")
    if inp == "yes":
        inserimento('Group_ID_9.Custody',"custody.csv")
    else:
        print("Inserimento non effettuato!")
