# -*- coding: utf-8 -*-
"""
Created on Mon Nov 13 18:10:49 2023

@author: Niccolò
"""
from popolamentoDB import inserimento
from popolamentoDBOPT import inserimentoOPT
import pyodbc
import csv

#funzione che crea la tabella a partire da output della funzione Get_set
def Participant_Table(elementi):
    file = open("participant.csv","w",newline='')
    writer = csv.writer(file,delimiter=',')
    
    writer.writerow(["participant_id","type","status","gender","age_group"])
    
    for i,e in enumerate (elementi):
        writer.writerow([i,e[0],e[1],e[2],e[3]])
    
    file.close()
    
#funzione che restituisce i vari profili dei participant senza duplicati
def Get_set(file):  
    participant_type = 'participant_type'
    participant_status = 'participant_status'
    participant_gender = 'participant_gender'
    participant_age_group = 'participant_age_group'
    
    participant = set() #qua ci inserisco le tuple di modo tale da avere elementi unici

    fp = open(file, "r", newline = '')
    reader = csv.reader(fp)

    header = 0

    for row in reader:
        if header == 0:
            idxType = row.index(participant_type)
            idxStatus = row.index(participant_status)
            idxGender = row.index(participant_gender)
            idx_age_group = row.index(participant_age_group)
            header += 1
            continue
        
        #per ogni iterazione creo lista per aggiungere elementi relativi al participant e poi aggiungo 
        #al set participant
        TempLista = []
        TempLista.append(row[idxType])
        TempLista.append(row[idxStatus])
        TempLista.append(row[idxGender])
        TempLista.append(row[idx_age_group])
        participant.add(tuple(TempLista))
    
    fp.close()
    return participant

if __name__ == '__main__':
    inp = input("Inserire \"yes\" per generare participant.csv, qualsiasi altro carattere altrimenti: ")
    if inp == "yes":
        participant = Get_set("Police.csv")
        Participant_Table(participant) #creo file participant.csv
        print("File participant.csv generato!")
    else:
        print("File participant.csv non generato!")
    
    inp = input("Inserire \"yes\" per inserire nella tablla Group_ID_9.Partecipant, qualsiasi altro carattere altrimenti: ")
    if inp == "yes":
        inserimento('Group_ID_9.Partecipant',"participant.csv")
    else:
        print("Inserimento non effettuato!")




