# -*- coding: utf-8 -*-
"""
Created on Tue Nov 14 08:59:42 2023

@author: Niccolò
"""

import pyodbc
import csv


def inserimento(tab, file):
    server = 'tcp:lds.di.unipi.it' 
    username = 'Group_ID_9' 
    password = 'DUBBNZJS'
    database = 'Group_ID_9_DB' 
    connectionString = 'DRIVER={ODBC Driver 17 for SQL Server};SERVER='+server+';DATABASE='+database+';UID='+username+';PWD='+ password
    cnxn = pyodbc.connect(connectionString,timeout = 5)

    cursor = cnxn.cursor()
    with open(file, 'r',encoding="utf-8") as file_insert:
        reader = csv.reader(file_insert)
        c = 0
        for lines in reader:
            if c == 0:
                header = ", ".join(lines)
                c += 1
            else:
                temp = '' 
                for a in lines:
                    
                    try:
                        int(a)
                        temp += a + ' '
                    except:
                        a = a.replace("\'",'\'\'') #per costruire query con apostrofo inserito doppio '
                        temp += '\''+a+'\'' + ' '
                
                temp = temp.split()
                temp = ",".join(temp)
                print(temp)
                query = f"INSERT INTO {tab} ({header}) VALUES ({temp});"
                print(query)
                cursor.execute(query)
                
        cnxn.commit()
        cursor.close()
                
    
         
