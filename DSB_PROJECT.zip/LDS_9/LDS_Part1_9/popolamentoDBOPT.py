# -*- coding: utf-8 -*-
"""
Created on Tue Nov 14 08:59:42 2023

@author: Niccolò
"""

import pyodbc
import csv


def inserimentoOPT(tab, file):
    server = 'tcp:lds.di.unipi.it' 
    username = 'Group_ID_9' 
    password = 'DUBBNZJS'
    database = 'Group_ID_9_DB' 
    connectionString = 'DRIVER={ODBC Driver 17 for SQL Server};SERVER='+server+';DATABASE='+database+';UID='+username+';PWD='+ password
    cnxn = pyodbc.connect(connectionString,timeout = 5)

    cursor = cnxn.cursor()
    cursor.fast_executemany = True #per velocizzare l'inserimento
    lista = []
    
    with open(file, 'r', encoding="utf-8") as file_insert:
        reader = csv.reader(file_insert)
        headers = next(reader)  #per ottenere l'header 
        placeholders = ', '.join(['?'] * len(headers)) #per creare tanti placeholder quante sono le colonne
        query = f"INSERT INTO {tab} ({', '.join(headers)}) VALUES ({placeholders})"

        #aggiungo tutte le linee in una lista
        for lines in reader: 
            lista.append(lines)

    
        cursor.executemany(query, lista)
    cnxn.commit()
    cursor.close()
                
    
         
