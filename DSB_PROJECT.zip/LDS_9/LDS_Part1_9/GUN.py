# -*- coding: utf-8 -*-
"""
Created on Mon Nov 13 17:41:06 2023

@author: Niccolò
"""
from popolamentoDB import inserimento
import pyodbc
import csv

#funzione che crea la tabella a partire da output della funzione Get_set
def Gun_Table(elementi):
    file = open("gun.csv","w",newline='')
    writer = csv.writer(file,delimiter=',')
    
    writer.writerow(["gun_id","is_stolen","gun_type"])
    
    for i,e in enumerate (elementi):
        writer.writerow([i,e[0],e[1]])
    
    file.close()

#funzione che restituisce le coppie gun_stolen e gun_type senza duplicati (utilizzando i set)
def Get_set(file):  
    gun_stolen = 'gun_stolen'
    gun_type = 'gun_type'

    StolenGtype = set() #qua ci inserisco le tuple di modo tale da avere elementi unici

    fp = open(file, "r", newline = '')
    reader = csv.reader(fp)

    header = 0

    for row in reader:
        if header == 0:
            idxGStolen = row.index(gun_stolen)
            idxGType = row.index(gun_type)
            header += 1
            continue
        
        #per ogni iterazione creo lista per aggiungere elementi relativi a gun e poi aggiungo al set
        #StolenGtype
        TempLista = []
        TempLista.append(row[idxGStolen])
        TempLista.append(row[idxGType])
        StolenGtype.add(tuple(TempLista))
    
    fp.close()
    return StolenGtype

StolenGtype = Get_set("Police.csv")    
Gun_Table(StolenGtype) #creo file gun.csv


#Popolamento tabella gun

if __name__ == '__main__':
    inp = input("Inserire \"yes\" per generare gun.csv, qualsiasi altro carattere altrimenti: ")
    if inp == "yes":
        StolenGtype  = Get_set("Police.csv")
        Gun_Table(StolenGtype) #creo file participant.csv
        print("File gun.csv generato!")
    else:
        print("File gun.csv non generato!")

    inp = input("Inserire \"yes\" per inserire nella tablla Group_ID_9.Gun, qualsiasi altro carattere altrimenti: ")
    if inp == "yes":
        inserimento('Group_ID_9.Gun',"gun.csv")
    else:
        print("Inserimento non effettuato!")