import os
import subprocess

if __name__ == '__main__':
    subprocess.run(['python', 'GUN.py'])
    subprocess.run(['python', 'PARTICIPANT.py'])
    subprocess.run(['python', 'DateXml2Csv.py']) 
    subprocess.run(['python', 'GEO.py'])
    subprocess.run(['python', 'CUSTODY.py'])
    