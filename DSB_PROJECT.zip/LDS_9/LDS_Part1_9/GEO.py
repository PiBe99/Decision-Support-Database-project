import reverse_geocoder as rg
import csv
import numpy as np
from popolamentoDB import inserimento
from popolamentoDBOPT import inserimentoOPT
import pyodbc

#apro file police e ottengo da esso le coordinate uniche
def get_unique_coordinates(filePolice):
    fp = open(filePolice, encoding="utf-8") 
    reader = csv.reader(fp)

    header = 0
    coordinate = []

    for row in reader:
        if header == 0:
            idxLat = row.index("latitude")
            idxLng = row.index("longitude")
            header += 1
            continue
        #aggiungo alla lista coordinate la tupla (lat,lng)
        coordinate.append(tuple([row[idxLat],row[idxLng]]))
    
    #ottengo le coordinate uniche
    coordinate = np.unique(coordinate,axis = 0) 
    coordinate = [tuple(e) for e in coordinate] #cast in lista di tuple per fornire effettuare il reverse_geocoding
    fp.close()
    return coordinate

#crea tabella geo
def Geo_table(coordinate):
    fp = open("geo.csv","w",encoding="utf-8",newline='')
    writer = csv.writer(fp)
    location = rg.search(coordinate)
    idx = 0

    header = ["geo_id", "city", "state", "country", "latitude", "longitude"]
    writer.writerow(header)#header del file

    for row in location:
        city = row.get("name") #name identifica la città 
        state = row.get("admin1") #admin1 identifica lo stato
        country = row.get("cc") #cc identifica il paese
    
        writer.writerow([idx,city,state,country,coordinate[idx][0],coordinate[idx][1]])
        idx += 1 #incremento geo_id

    fp.close()


if __name__ == '__main__':
    inp = input("Inserire \"yes\" per generare geo.csv, qualsiasi altro carattere altrimenti: ")
    if inp == "yes":
        coordinate = get_unique_coordinates("Police.csv")
        Geo_table(coordinate)
        print("File geo.csv generato!")
    else:
        print("File geo.csv non generato!")
    inp = input("Inserire \"yes\" per inserire nella tablla Group_ID_9.Geography, qualsiasi altro carattere altrimenti: ")
    if inp == "yes":
        inserimento('Group_ID_9.Geography',"geo.csv")
    else:
        print("Inserimento non effettuato!")