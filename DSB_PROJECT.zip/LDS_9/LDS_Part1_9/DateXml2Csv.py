import xml.etree.ElementTree as ET
import datetime
import csv
from popolamentoDB import inserimento
import os


def get_len(tree):
    count = 0
    for a in tree.iter():
        temporary = []
        if a.tag == 'date_pk':
            count += 1
    return count
    
#xml_path = 'dates.xml'
def create_data_4_csv(xml_file_path):
    tree = ET.parse(xml_file_path)
    root = tree.getroot()
    
    lista_date = []
    for idx in range(get_len(tree)):
        lista_key = []
        data = root[idx][0].text
        data_split = data[:10].split('-')
        year = data_split[0]
        month = data_split[1]
        day = data_split[2]
        d_name = datetime.datetime(int(year),int(month),int(day)).strftime("%A")
        d_quarter = (int(month)-1)//3 + 1 
        lista_key.append(root[idx][1].text) #ID
        lista_key.append(data[:10]) #GIORNO INTERO
        lista_key.append(year)#ANNO
        lista_key.append(month)#MESE
        lista_key.append(day)#GIORNO
        lista_key.append(d_quarter)#QUADRIMESTRE
        lista_key.append(d_name)#NOME GIOTNO
        lista_date.append(lista_key)

    return lista_date

def write_csv():
    xml_file_path = 'dates.xml'
    header = ['date_id', 'date', 'year', 'month', 'day', 'quarter', 'day_of_the_week']
    with open('date.csv','w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(header)
        writer.writerows(create_data_4_csv(xml_file_path))

if __name__ == '__main__':
    inp = input("Inserire \"yes\" per generare date.csv, qualsiasi altro carattere altrimenti: ")
    if inp == "yes":
        write_csv()
        print("File date.csv generato!")
    else:
        print("File date.csv non generato!")

    inp = input("Inserire \"yes\" per inserire nella tablla Group_ID_9.Date, qualsiasi altro carattere altrimenti: ")
    if inp == "yes":
        inserimento('Group_ID_9.Date',"date.csv")
    else:
        print("Inserimento non effettuato!")
    
